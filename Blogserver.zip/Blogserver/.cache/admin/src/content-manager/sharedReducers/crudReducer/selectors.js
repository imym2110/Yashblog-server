const selectCrudReducer = (state) => state['content-manager_editViewCrudReducer'];

export default selectCrudReducer;
