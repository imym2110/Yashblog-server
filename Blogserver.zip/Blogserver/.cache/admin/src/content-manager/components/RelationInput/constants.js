export const RELATION_ITEM_HEIGHT = 50;
export const RELATION_GUTTER = 4;
