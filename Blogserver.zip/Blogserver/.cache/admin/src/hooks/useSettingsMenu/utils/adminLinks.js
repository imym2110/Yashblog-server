import customAdminLinks from 'ee_else_ce/hooks/useSettingsMenu/utils/customAdminLinks';
import defaultAdminLinks from './defaultAdminLinks';

export default [...customAdminLinks, ...defaultAdminLinks];
